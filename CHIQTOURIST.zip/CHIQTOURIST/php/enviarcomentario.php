<!DOCTYPE html>
<html>
<head>
    <title>Caja de Comentarios</title>
</head>
<body>

<?php
    // Verificar si se ha enviado un comentario
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Obtener el comentario del formulario
        $comentario = $_POST["comentario"];

        // Validar y procesar el comentario (puedes agregar más validaciones según tus necesidades)

        // Guardar el comentario en un archivo o base de datos (en este ejemplo, simplemente lo mostramos)
        echo "<p>Comentario enviado: " . htmlspecialchars($comentario) . "</p>";
    }
?>

<!-- Formulario de comentarios -->
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <label for="comentario">Comentario:</label><br>
    <textarea name="comentario" rows="4" cols="50"></textarea><br>
    <input type="submit" value="Enviar Comentario">
</form>

</body>
</html>

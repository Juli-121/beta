<!DOCTYPE html>
<?php
	$host_db="localhost";
	$user_db="root";
	$pass_db="";
	$bd_name="noticias";
	$tabla="comentarios";
 
	$conexion=new mysqli($host_db, $user_db, $pass_db, $bd_name);
	if ($conexion -> connect_error) {
		die("La conexion fallo". $conexion -> connect_error);
	}
 
	$comentario="SELECT * FROM comentarios ORDER BY id DESC";
	$resultado=$conexion -> query($comentario);
	while ($fila=mysqli_fetch_row($resultado)) {
		echo "<b>Mensaje</b> #".$fila[0]."; ";
		echo "<b>Nombre: </b>".$fila[1]."; ";
		echo "<b>Fecha: </b>".$fila[2]."; ";
		echo "<br><br>";
		echo $fila[3];
		echo "<hr>";
		echo "<br>";
	}
 
?>
<form action="PHP/Procesar_Mensaje.php" method="POST">
	<h3>Nombre de Usuario</h3>
	<input type="text" size="50" name="usuarios" required>
	<h3>Escribe tu mensaje</h3>
	<textarea rows="10" cols="100" name="comentario" required></textarea>
	<br>
	<br>
	<input type="submit" value="Enviar Comentario" >
</form>
 
 
 
 
// ***** Y este el codigo php del archivo Procesar_Mensaje.php necesario para poder guardar los comentarios hechos *****
 
<?php
	$host_db="localhost";//nombre del servidor
	$user_db="root";//nombre de usuario
	$pass_db="";//contraseña
	$bd_name="noticias";//nombre de mi base de datos
 
 
	$conexion=new mysqli($host_db, $user_db, $pass_db, $bd_name);
	if ($conexion -> connect_error) {
		die("La conexion fallo". $conexion -> connect_error);
	}
 
	$insertar="INSERT INTO comentarios (usuario, mensaje) VALUES ('".$_POST["usuarios"]."','".$_POST["comentario"]."')";
 
	if ($conexion -> query($insertar) == true) {
		?>
 
		<script language="JavaScript">
			//mensaje
			alert("Comentario enviado Correctamente");
			window.location.href='index.php';
		</script>
 
		<?php
	}
?>
